package com.studiovocalpro.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var video: VideoView
    private lateinit var selectedFile: TextView
    private lateinit var status: TextView
    private val teal = Color.rgb(25, 167, 138)
    private val dark = Color.rgb(16, 29, 37)
    private val panel = Color.rgb(29, 43, 51)
    private var videoUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            setPadding(dp(18), dp(18), dp(18), dp(20))
        }
        val scroll = android.widget.ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(-1, -1))

        content.addView(label("🎙  STUDIO VOCAL PRO AI", 22, Color.WHITE, true))
        content.addView(label("Mini studio untuk video nyanyian & gitar", 14, 0xFFB8C8C8.toInt(), false))
        content.addView(space(18))

        val choose = button("PILIH VIDEO DARI GALERI") { openVideoPicker() }
        content.addView(choose)
        selectedFile = label("Belum ada video dipilih", 13, 0xFFB8C8C8.toInt(), false)
        content.addView(selectedFile)
        video = VideoView(this).apply {
            setBackgroundColor(Color.BLACK)
            setMediaController(android.widget.MediaController(this@MainActivity))
        }
        content.addView(video, LinearLayout.LayoutParams(-1, dp(210)).apply { topMargin = dp(10) })

        content.addView(space(18))
        content.addView(label("PENGATURAN STUDIO", 17, Color.WHITE, true))
        content.addView(label("Kontrol berikut disiapkan untuk mesin pemrosesan audio.", 12, 0xFFB8C8C8.toInt(), false))
        addSlider(content, "Noise reduction", 35)
        addSlider(content, "Kejernihan vokal", 55)
        addSlider(content, "Kehangatan gitar", 50)
        addSlider(content, "Compressor", 45)
        addSlider(content, "Reverb", 10)
        addSlider(content, "Output volume", 80)

        content.addView(space(12))
        status = label("Status: pilih video untuk memulai.", 13, 0xFFFFD18A.toInt(), false)
        content.addView(status)
        content.addView(space(8))
        content.addView(button("▶  PUTAR VIDEO") {
            if (videoUri == null) toast("Pilih video terlebih dahulu")
            else video.start()
        })
        content.addView(space(8))
        content.addView(button("HENTIKAN") { video.pause() }, secondary = true)
        content.addView(space(8))
        content.addView(button("PROSES DENGAN AI", enabled = false) {})
        content.addView(label("Mesin AI pemisah vokal/gitar dan noise removal belum terintegrasi pada build awal ini. Tombol proses akan diaktifkan setelah model AI dan pipeline ekspor selesai dipasang.", 12, 0xFFB8C8C8.toInt(), false))
        content.addView(space(18))
        content.addView(label("Studio Vocal Pro AI • Versi fondasi 0.1.0", 11, 0xFF84979B.toInt(), false))
        setContentView(root)
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, 100)
    }

    @Deprecated("Legacy activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            videoUri = uri
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            video.setVideoURI(uri)
            selectedFile.text = "Video dipilih: ${uri.lastPathSegment ?: "file video"}"
            status.text = "Status: video siap diputar."
        }
    }

    private fun addSlider(parent: LinearLayout, title: String, initial: Int) {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(6))
            setBackgroundColor(panel)
        }
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val name = TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 14f }
        val value = TextView(this).apply { text = "$initial%"; setTextColor(0xFF83DCC7.toInt()); textSize = 13f }
        line.addView(name, LinearLayout.LayoutParams(0, -2, 1f)); line.addView(value)
        val seek = SeekBar(this).apply { max = 100; progress = initial }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { value.text = "$p%" }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        wrap.addView(line); wrap.addView(seek)
        parent.addView(wrap, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun button(text: String, enabled: Boolean = true, secondary: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; isEnabled = enabled
        setTextColor(if (secondary) Color.WHITE else Color.WHITE)
        setBackgroundColor(if (secondary) panel else teal)
        alpha = if (enabled) 1f else .45f
        setOnClickListener { action() }
    }

    private fun space(h: Int) = android.view.View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
