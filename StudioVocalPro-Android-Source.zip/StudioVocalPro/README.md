# Studio Vocal Pro AI — Android starter project

Versi 0.1.0 adalah fondasi aplikasi Android native:
- pemilih video melalui Android Storage Access Framework;
- pratinjau video;
- UI kontrol studio (noise reduction, vocal clarity, guitar warmth, compressor, reverb, output);
- status integrasi AI yang belum aktif.

## Penting
Build ini **belum memproses atau mengekspor audio**. Slider adalah UI awal dan belum terhubung ke DSP. AI vocal/guitar separation dan noise removal memerlukan model inferensi (misalnya model separation yang lisensinya sesuai), pipeline audio, optimasi perangkat, serta pengujian. Jangan menganggap tombol/slider sebagai efek yang sudah bekerja.

## Membuka dan membangun APK
1. Buka folder `StudioVocalPro` dengan Android Studio terbaru.
2. Izinkan Gradle sincronisasi dan unduh Android Gradle Plugin serta SDK platform 35.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Persyaratan: Android Studio, JDK 17, Android SDK platform 35, dan koneksi internet untuk mengunduh komponen Gradle pertama kali.
